package com.example.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.example.model.Locationstatus;

@Service
public class CaronaDataService {
	
    private static String CORONA_DATA_URL_COUNTRY = "https://api.covid19api.com/summary";
    private static String CORONA_DATA_URL_STATE = "https://api.covid19india.org/data.json";
    private ArrayList<Locationstatus> allStats;
    
    public ArrayList<Locationstatus> fetchCountryCoronaData(String countryname) throws Exception {
    	URL obj=new URL(CORONA_DATA_URL_COUNTRY);
    	HttpsURLConnection con=(HttpsURLConnection) obj.openConnection();
    	con.setRequestMethod("GET");
    	BufferedReader in=new BufferedReader(new InputStreamReader(con.getInputStream()));
    	String inputLine;
    	StringBuffer response=new StringBuffer();
    	while((inputLine=in.readLine())!=null)
    	{
    		response.append(inputLine);
    	}
    	in.close();
    	JSONObject carona_json=new JSONObject(response.toString());
    	JSONArray country_arr=carona_json.getJSONArray("Countries");
    	ArrayList<Locationstatus> newStats = new ArrayList<>();
    	for(int i=0;i<country_arr.length();i++)
    	{
    		JSONObject js=country_arr.getJSONObject(i);
    		Locationstatus ls=new Locationstatus();
    		if(js.getString("Country").equalsIgnoreCase(countryname))
    		{
    			ls.setCountry(js.getString("Country"));
        		ls.setConfirmed(js.getInt("TotalConfirmed"));
        		ls.setActive(js.getInt("NewConfirmed"));
        		ls.setRecovered(js.getInt("TotalRecovered"));
        		ls.setDeceased(js.getInt("TotalDeaths"));
        		newStats.add(ls);
    		}
    	}
    	this.allStats = newStats;
    	return allStats;
    }
    public ArrayList<Locationstatus> fetchStateCoronaData(String statename) throws Exception {
    	URL obj=new URL(CORONA_DATA_URL_STATE);
    	HttpsURLConnection con=(HttpsURLConnection) obj.openConnection();
    	con.setRequestMethod("GET");
    	BufferedReader in=new BufferedReader(new InputStreamReader(con.getInputStream()));
    	String inputLine;
    	StringBuffer response=new StringBuffer();
    	while((inputLine=in.readLine())!=null)
    	{
    		response.append(inputLine);
    	}
    	in.close();
    	JSONObject carona_json=new JSONObject(response.toString());
    	JSONArray state_arr=carona_json.getJSONArray("statewise");
    	ArrayList<Locationstatus> newStats = new ArrayList<>();
    	for(int i=0;i<state_arr.length();i++)
    	{
    		JSONObject js=state_arr.getJSONObject(i);
    		Locationstatus ls=new Locationstatus();
    		if(js.getString("state").equalsIgnoreCase(statename))
    		{
    			ls.setState(js.getString("state"));
        		ls.setConfirmed(js.getInt("confirmed"));
        		ls.setActive(js.getInt("active"));
        		ls.setRecovered(js.getInt("recovered"));
        		ls.setDeceased(js.getInt("deaths"));
        		newStats.add(ls);
    		}
    	}
    	this.allStats = newStats;
    	return allStats;
    }


}
