package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class CountryStateData {
	@Id
	@GeneratedValue
private int csid;
public int getCsid() {
	return csid;
}
public void setCsid(int csid) {
	this.csid = csid;
}
private String country;
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
private String state;
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}

@Override
public String toString() {
	return "CountryStateData [csid=" + csid + ", country=" + country + ", state=" + state + "]";
}

}
