package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.model.Locationstatus;
import com.example.service.CaronaDataService;
@Configuration
@Controller
@ComponentScan("com.example.service")
@EnableAutoConfiguration
public class HomeController {
	@Autowired
	private CaronaDataService carona;
	
	protected Map<String,List<String>> referenceData(HttpServletRequest request) throws Exception {

		
		Map<String,List<String>> referenceData=new HashMap<String,List<String>>();
		ArrayList<String> country = new ArrayList<String>();
		country.add("India");
		country.add("China");
		country.add("Singapore");
		country.add("Malaysia");
		referenceData.put("countryList", country);

		ArrayList<String> javaSkill = new ArrayList<String>();
		javaSkill.add("Hibernate");
		javaSkill.add("Spring");
		javaSkill.add("Apache Wicket");
		javaSkill.add("Struts");
		referenceData.put("javaSkillsList", javaSkill);

		return referenceData;
	}
	
	@RequestMapping("home")
	public ModelAndView home(CountryStateData cs)
	{
		ModelAndView mv=new ModelAndView();
		mv.addObject("obj",cs);
		mv.setViewName("home.jsp");
		return mv;
	}
	@RequestMapping("/getdata")
	    public String main(@RequestParam("Country")String countryname,@RequestParam("State")String statename,Model model) throws Exception{
	        ArrayList<Locationstatus> locationstatus = carona.fetchCountryCoronaData(countryname);
	        ArrayList<Locationstatus> locationstatus_state = carona.fetchStateCoronaData(statename);
	        int confirmed=locationstatus.stream().mapToInt(locationStat -> locationStat.getConfirmed()).sum();
	        int active=locationstatus.stream().mapToInt(locationStat -> locationStat.getActive()).sum();
	        int recovered=locationstatus.stream().mapToInt(locationStat -> locationStat.getRecovered()).sum();
	        int deceased=locationstatus.stream().mapToInt(locationStat -> locationStat.getDeceased()).sum();
	        
	        int confirmed_state=locationstatus_state.stream().mapToInt(locationStat -> locationStat.getConfirmed()).sum();
	        int active_state=locationstatus_state.stream().mapToInt(locationStat -> locationStat.getActive()).sum();
	        int recovered_state=locationstatus_state.stream().mapToInt(locationStat -> locationStat.getRecovered()).sum();
	        int deceased_state=locationstatus_state.stream().mapToInt(locationStat -> locationStat.getDeceased()).sum();
	        
	        model.addAttribute("country",countryname);
	        model.addAttribute("confirmed",confirmed);
	        model.addAttribute("active",active);
	        model.addAttribute("recovered",recovered);
	        model.addAttribute("deceased",deceased);
	        model.addAttribute("state", statename);
	        model.addAttribute("confirmed_state",confirmed_state);
	        model.addAttribute("active_state",active_state);
	        model.addAttribute("recovered_state",recovered_state);
	        model.addAttribute("deceased_state",deceased_state);
	        
	        return "updates.jsp";
	    }
	
}
